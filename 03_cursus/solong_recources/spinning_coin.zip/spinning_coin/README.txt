~~ ThePeeps191 ~~

This is a simple pixel art spinning coin I made with Libresprite for a platformer. It has 10 animated frames. Attribution is not required but I'd highly appreciate it.